using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AplicativoMejorado.Views.Citas
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
