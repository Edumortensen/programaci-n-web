﻿using CapaDatos;
using CapaEntidad;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace AplicativoMejorado.Controllers
{
    public class TratamientosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public List<TratamientosCLS> listarTratamientos()
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.listarTratamientos();
        }

        public int GuardarTratamiento(TratamientosCLS objTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.GuardarTratamiento(objTratamiento);
        }

        public int EliminarTratamiento(int idTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.EliminarTratamiento(idTratamiento);
        }

        public TratamientosCLS recuperarTratamiento(int idTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.recuperarTratamiento(idTratamiento);
        }

        public int GuardarCambioTratamiento(TratamientosCLS objTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.GuardarCambioTratamiento(objTratamiento);
        }
    }
}
