﻿window.onload = function () {
    listarFacturacion();
};

function filtrarFacturacion() {
    let pacienteId = get("txtPacienteId");
    let metodoPago = get("txtMetodoPago");

    if (pacienteId == "" && metodoPago == "") {
        listarFacturacion();
    } else {
        objFactura.url = `Facturacion/filtrarFacturacion/?pacienteId=${pacienteId}&metodoPago=${metodoPago}`;
        pintar(objFactura);
    }
}

let objFactura;

async function listarFacturacion() {
    objFactura = {
        url: "Facturacion/listarFacturacion",
        cabeceras: ["ID Factura", "Paciente ID", "Monto", "Metodo de Pago", "Fecha de Pago"],
        propiedades: ["id", "pacienteId", "monto", "metodoPago", "fechaPago"],
        divContenedorTabla: "divContenedorTabla",
        editar: true,
        eliminar: true,
        propiedadId: "id"
    }

    pintar(objFactura);
}

function LimpiarFacturacion() {
    LimpiarDatos("frmBusqueda");
    listarFacturacion();
}

function GuardarFacturacion() {
    let forma = document.getElementById("frmCrearFactura");
    let frm = new FormData(forma);

    confirmacionCreacion("Guardar Nueva Factura", "Quiero guardar", function () {
        fetchPost("Facturacion/GuardarFacturacion", "text", frm, function (res) {
            listarFacturacion();
            LimpiarDatos("frmCrearFactura");

            let modalElement = document.getElementById("insertModal");
            let modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
            }

            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());

            let toast = new bootstrap.Toast(document.getElementById("toastSuccess"));
            toast.show();
        });
    });
}

function Eliminar(id) {
    fetchGet(`Facturacion/recuperarFacturacion/?idFacturacion=${id}`, "json", function (res) {
        mostrarAlertaEliminar("Borrar la Factura", `¿Desea eliminar la factura para el paciente ID: ${res.pacienteId}?`, function () {
            fetchGet("Facturacion/EliminarFacturacion/?idFacturacion=" + id, "text", function (respt) {
                listarFacturacion();
                Swal.fire({
                    title: "Eliminado!",
                    text: `La factura con paciente ID: ${res.pacienteId} ha sido eliminada.`,
                    icon: "success"
                });
            });
        });
    });
}

function Editar(id) {
    let modal = new bootstrap.Modal(document.getElementById("editModal"));
    modal.show();
    fetchGet(`Facturacion/recuperarFacturacion/?idFacturacion=${id}`, "json", function (res) {
        if (res) {
            set("editid", res.id);
            set("editpacienteId", res.pacienteId);
            set("editmonto", res.monto);
            set("editmetodoPago", res.metodoPago);
            set("editfechaPago", res.fechaPago);
        }
    });
}

function GuardarCambioFacturacion() {
    let forma = document.getElementById("frmEditar");
    let frm = new FormData(forma);

    confirmacionActualizacion("Actualizar Factura", `¿Desea actualizar la factura para el paciente ID: ${document.getElementById("editpacienteId").value}?`, function () {
        fetchPost("Facturacion/GuardarCambioFacturacion", "text", frm, function (rspt) {
            listarFacturacion();
            LimpiarDatos("frmEditar");

            Swal.fire({
                title: "Actualizado!",
                text: `La factura ha sido actualizada.`,
                icon: "success"
            });

            let modalElement = document.getElementById("editModal");
            let modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
            modal.hide();

            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());

            let toast = new bootstrap.Toast(document.getElementById("toastSuccessEdit"));
            toast.show();
        });
    });
}
