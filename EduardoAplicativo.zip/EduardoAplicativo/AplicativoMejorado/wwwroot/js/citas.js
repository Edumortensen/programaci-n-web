﻿window.onload = function () {
    listarCitas();
};

function filtrarCitas() {
    let estado = get("txtEstado");
    let pacienteId = get("txtPacienteId");
    let medicoId = get("txtMedicoId");

    if (estado == "" && pacienteId == "" && medicoId == "") {
        listarCitas();
    } else {
        objCita.url = `Citas/filtrarCitas/?estado=${estado}&pacienteId=${pacienteId}&medicoId=${medicoId}`;
        pintar(objCita);
    }
}

let objCita;

async function listarCitas() {
    objCita = {
        url: "Citas/listarCitas",
        cabeceras: ["Id Cita", "Paciente ID", "Medico ID", "Fecha y Hora", "Estado"],
        propiedades: ["id", "pacienteId", "medicoId", "fechaHora", "estado"],
        divContenedorTabla: "divContenedorTabla",
        editar: true,
        eliminar: true,
        propiedadId: "id"
    }

    pintar(objCita);
}

function LimpiarCitas() {
    LimpiarDatos("frmBusqueda");
    listarCitas();
}

function GuardarCita() {
    let forma = document.getElementById("frmCrearCita"); // Usar el formulario del modal
    let frm = new FormData(forma);

    confirmacionCreacion("Guardar Nueva Cita", "Quiero guardar", function () {
        fetchPost("Citas/GuardarCita", "text", frm, function (res) {
            listarCitas();
            LimpiarDatos("frmCrearCita");

            // Cerrar el modal correctamente
            let modalElement = document.getElementById("insertModal");
            let modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
            }

            // Eliminar manualmente el fondo oscuro si persiste
            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());

            // Mostrar el toast de éxito
            let toast = new bootstrap.Toast(document.getElementById("toastSuccess"));
            toast.show();
        });
    });
}

function Eliminar(id) {
    fetchGet(`Citas/recuperarCita/?idCita=${id}`, "json", function (res) {
        mostrarAlertaEliminar("Borrar la Cita", `¿Desea eliminar la cita para el paciente ID: ${res.pacienteId}?`, function () {
            fetchGet("Citas/EliminarCita/?idCita=" + id, "text", function (respt) {
                listarCitas();
                Swal.fire({
                    title: "Eliminado!",
                    text: `La cita con paciente ID: ${res.pacienteId} ha sido eliminada.`,
                    icon: "success"
                });
            });
        });
    });
}

function Editar(id) {
    let modal = new bootstrap.Modal(document.getElementById("editModal"));
    modal.show();
    fetchGet(`Citas/recuperarCita/?idCita=${id}`, "json", function (res) {
        if (res) {
            set("editid", res.id);
            set("editpacienteId", res.pacienteId);
            set("editmedicoId", res.medicoId);
            set("editfechaHora", res.fechaHora);
            set("editestado", res.estado);
        }
    });
}

function GuardarCambioCita() {
    let forma = document.getElementById("frmEditar");
    let frm = new FormData(forma);

    confirmacionActualizacion("Actualizar Cita", `¿Desea actualizar la cita para el paciente ID: ${document.getElementById("editpacienteId").value}?`, function () {
        fetchPost("Citas/GuardarCambioCita", "text", frm, function (rspt) {
            listarCitas();
            LimpiarDatos("frmEditar");

            Swal.fire({
                title: "Actualizado!",
                text: `La cita ha sido actualizada.`,
                icon: "success"
            });

            let modalElement = document.getElementById("editModal");
            let modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
            modal.hide();

            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());

            let toast = new bootstrap.Toast(document.getElementById("toastSuccessEdit"));
            toast.show();
        });
    });
}
