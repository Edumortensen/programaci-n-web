﻿window.onload = function () {
    listarTratamientos();
};

function filtrarTratamientos() {
    let pacienteId = get("txtPacienteId");
    let fecha = get("txtFecha");

    if (pacienteId == "" && fecha == "") {
        listarTratamientos();
    } else {
        objTratamiento.url = `Tratamientos/filtrarTratamientos/?pacienteId=${pacienteId}&fecha=${fecha}`;
        pintar(objTratamiento);
    }
}

let objTratamiento;

async function listarTratamientos() {
    objTratamiento = {
        url: "Tratamientos/listarTratamientos",
        cabeceras: ["Id Tratamiento", "Paciente ID", "Descripción", "Fecha", "Costo"],
        propiedades: ["id", "pacienteId", "descripcion", "fecha", "costo"],
        divContenedorTabla: "divContenedorTabla",
        editar: true,
        eliminar: true,
        propiedadId: "id"
    }

    pintar(objTratamiento);
}

function LimpiarTratamientos() {
    LimpiarDatos("frmBusqueda");
    listarTratamientos();
}

function GuardarTratamiento() {
    let forma = document.getElementById("frmCrearTratamiento");
    let frm = new FormData(forma);

    confirmacionCreacion("Guardar Nuevo Tratamiento", "Quiero guardar", function () {
        fetchPost("Tratamientos/GuardarTratamiento", "text", frm, function (res) {
            listarTratamientos();
            LimpiarDatos("frmCrearTratamiento");

            let modalElement = document.getElementById("insertModal");
            let modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
            }

            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());
            let toast = new bootstrap.Toast(document.getElementById("toastSuccess"));
            toast.show();
        });
    });
}

function Eliminar(id) {
    fetchGet(`Tratamientos/recuperarTratamiento/?idTratamiento=${id}`, "json", function (res) {
        mostrarAlertaEliminar("Borrar el Tratamiento", `¿Desea eliminar el tratamiento ID: ${res.id}?`, function () {
            fetchGet("Tratamientos/EliminarTratamiento/?idTratamiento=" + id, "text", function (respt) {
                listarTratamientos();
                Swal.fire({
                    title: "Eliminado!",
                    text: `El tratamiento con ID: ${res.id} ha sido eliminado.`,
                    icon: "success"
                });
            });
        });
    });
}

function Editar(id) {
    let modal = new bootstrap.Modal(document.getElementById("editModal"));
    modal.show();
    fetchGet(`Tratamientos/recuperarTratamiento/?idTratamiento=${id}`, "json", function (res) {
        if (res) {
            set("editid", res.id);
            set("editpacienteId", res.pacienteId);
            set("editdescripcion", res.descripcion);
            set("editfecha", res.fecha);
            set("editcosto", res.costo);
        }
    });
}

function GuardarCambioTratamiento() {
    let forma = document.getElementById("frmEditar");
    let frm = new FormData(forma);

    confirmacionActualizacion("Actualizar Tratamiento", `¿Desea actualizar el tratamiento ID: ${document.getElementById("editid").value}?`, function () {
        fetchPost("Tratamientos/GuardarCambioTratamiento", "text", frm, function (rspt) {
            listarTratamientos();
            LimpiarDatos("frmEditar");

            Swal.fire({
                title: "Actualizado!",
                text: `El tratamiento ha sido actualizado.`,
                icon: "success"
            });

            let modalElement = document.getElementById("editModal");
            let modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
            modal.hide();
            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());

            let toast = new bootstrap.Toast(document.getElementById("toastSuccessEdit"));
            toast.show();
        });
    });
}
