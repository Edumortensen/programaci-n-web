﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using CapaEntidad;
using System.Collections.Generic;

namespace CapaNegocio
{
    public class TratamientosBL
    {
        public List<TratamientosCLS> listarTratamientos()
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.listarTratamientos();
        }

        public int GuardarTratamiento(TratamientosCLS objTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.GuardarTratamiento(objTratamiento);
        }

        public int EliminarTratamiento(int idTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.EliminarTratamiento(idTratamiento);
        }

        public TratamientosCLS recuperarTratamiento(int idTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.recuperarTratamiento(idTratamiento);
        }

        public int GuardarCambioTratamiento(TratamientosCLS objTratamiento)
        {
            TratamientosDAL obj = new TratamientosDAL();
            return obj.GuardarCambioTratamiento(objTratamiento);
        }
    }
}
