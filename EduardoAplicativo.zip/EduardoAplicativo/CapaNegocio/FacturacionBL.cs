﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;

namespace CapaNegocio
{
    public class FacturacionBL
    {
        public List<FacturacionCLS> listarFacturacion()
        {
            FacturacionDAL obj = new FacturacionDAL();
            return obj.listarFacturacion();
        }

        public List<FacturacionCLS> filtrarFacturacion(FacturacionCLS objFacturacion)
        {
            FacturacionDAL obj = new FacturacionDAL();
            return obj.filtrarFacturacion(objFacturacion);
        }

        public int GuardarFacturacion(FacturacionCLS objFacturacion)
        {
            FacturacionDAL obj = new FacturacionDAL();
            return obj.GuardarFacturacion(objFacturacion);
        }

        public int EliminarFacturacion(int idFacturacion)
        {
            FacturacionDAL objDAL = new FacturacionDAL();
            return objDAL.EliminarFacturacion(idFacturacion);
        }

        public FacturacionCLS recuperarFacturacion(int idFacturacion)
        {
            FacturacionDAL obj = new FacturacionDAL();
            return obj.recuperarFacturacion(idFacturacion);
        }

        public int GuardarCambioFacturacion(FacturacionCLS objFacturacion)
        {
            FacturacionDAL obj = new FacturacionDAL();
            return obj.GuardarCambioFacturacion(objFacturacion);
        }
    }
}
