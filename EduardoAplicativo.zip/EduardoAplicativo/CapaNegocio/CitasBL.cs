﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class CitasBL
    {
        public List<CitasCLS> listarCitas()
        {
            CitasDAL obj = new CitasDAL();
            return obj.listarCitas();
        }

        public List<CitasCLS> filtrarCitas(CitasCLS objCita)
        {
            CitasDAL obj = new CitasDAL();
            return obj.filtrarCitas(objCita);
        }

        public int GuardarCita(CitasCLS objCita)
        {
            CitasDAL obj = new CitasDAL();
            return obj.GuardarCita(objCita);
        }

        public int EliminarCita(int idCita)
        {
            CitasDAL objDAL = new CitasDAL();
            return objDAL.EliminarCita(idCita);
        }

        public CitasCLS recuperarCita(int idCita)
        {
            CitasDAL obj = new CitasDAL();
            return obj.recuperarCita(idCita);
        }

        public int GuardarCambioCita(CitasCLS objCita)
        {
            CitasDAL obj = new CitasDAL();
            return obj.GuardarCambioCita(objCita);
        }
    }
}
