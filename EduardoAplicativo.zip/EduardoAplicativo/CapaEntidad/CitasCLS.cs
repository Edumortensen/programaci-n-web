﻿namespace CapaEntidad
{
    public class CitasCLS
    {
        public int Id { get; set; }
        public int PacienteId { get; set; }
        public int MedicoId { get; set; }
        public DateTime FechaHora { get; set; }
        public string Estado { get; set; }
    }
}
