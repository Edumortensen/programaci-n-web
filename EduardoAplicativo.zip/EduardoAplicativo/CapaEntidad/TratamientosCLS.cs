﻿namespace CapaEntidad
{
    public class TratamientosCLS
    {
        public int Id { get; set; }
        public int PacienteId { get; set; }
        public string Descripcion { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Costo { get; set; }
    }
}

