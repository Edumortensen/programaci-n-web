﻿using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class TratamientosDAL : CadenaDAL
    {
        public List<TratamientosCLS> listarTratamientos()
        {
            List<TratamientosCLS> lista = new List<TratamientosCLS>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, Descripcion, Fecha, Costo FROM Tratamientos", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                lista.Add(new TratamientosCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    Descripcion = dr.GetString(2),
                                    Fecha = dr.GetDateTime(3),
                                    Costo = dr.GetDecimal(4)
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en listarTratamientos: {ex.Message}");
                    lista = new List<TratamientosCLS>();
                }
            }
            return lista;
        }

        public int GuardarTratamiento(TratamientosCLS obj)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Tratamientos (PacienteId, Descripcion, Fecha, Costo) VALUES (@PacienteId, @Descripcion, @Fecha, @Costo)", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@PacienteId", obj.PacienteId);
                        cmd.Parameters.AddWithValue("@Descripcion", obj.Descripcion);
                        cmd.Parameters.AddWithValue("@Fecha", obj.Fecha);
                        cmd.Parameters.AddWithValue("@Costo", obj.Costo);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }

        public int EliminarTratamiento(int idTratamiento)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Tratamientos WHERE Id = @IdTratamiento", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@IdTratamiento", idTratamiento);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }

        public TratamientosCLS recuperarTratamiento(int idTratamiento)
        {
            TratamientosCLS obj = null;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, Descripcion, Fecha, Costo FROM Tratamientos WHERE Id = @IdTratamiento", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@IdTratamiento", idTratamiento);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                obj = new TratamientosCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    Descripcion = dr.GetString(2),
                                    Fecha = dr.GetDateTime(3),
                                    Costo = dr.GetDecimal(4)
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en recuperarTratamiento: {ex.Message}");
                }
            }
            return obj;
        }

        public int GuardarCambioTratamiento(TratamientosCLS obj)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("UPDATE Tratamientos SET PacienteId = @PacienteId, Descripcion = @Descripcion, Fecha = @Fecha, Costo = @Costo WHERE Id = @Id", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Id", obj.Id);
                        cmd.Parameters.AddWithValue("@PacienteId", obj.PacienteId);
                        cmd.Parameters.AddWithValue("@Descripcion", obj.Descripcion);
                        cmd.Parameters.AddWithValue("@Fecha", obj.Fecha);
                        cmd.Parameters.AddWithValue("@Costo", obj.Costo);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }
    }
}
