﻿using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class FacturacionDAL : CadenaDAL
    {

        public List<FacturacionCLS> listarFacturacion()
        {
            List<FacturacionCLS> lista = new List<FacturacionCLS>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, Monto, MetodoPago, FechaPago FROM Facturacion", cn))
                    {
                        cmd.CommandType = CommandType.Text;

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                lista.Add(new FacturacionCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    Monto = dr.GetDecimal(2),
                                    MetodoPago = dr.GetString(3),
                                    FechaPago = dr.GetDateTime(4)
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en listarFacturacion: {ex.Message}");
                    lista = new List<FacturacionCLS>(); // Devolver lista vacía en vez de null
                }
            }
            return lista;
        }

        public List<FacturacionCLS> filtrarFacturacion(FacturacionCLS obj)
        {
            List<FacturacionCLS> lista = new List<FacturacionCLS>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, Monto, MetodoPago, FechaPago FROM Facturacion WHERE (@PacienteId IS NULL OR PacienteId = @PacienteId) AND (@FechaPago IS NULL OR FechaPago = @FechaPago)", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@PacienteId", (object)obj.PacienteId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@FechaPago", (object)obj.FechaPago ?? DBNull.Value);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                lista.Add(new FacturacionCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    Monto = dr.GetDecimal(2),
                                    MetodoPago = dr.GetString(3),
                                    FechaPago = dr.GetDateTime(4)
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en filtrarFacturacion: {ex.Message}");
                    lista = new List<FacturacionCLS>(); // Devolver lista vacía en vez de null
                }
            }
            return lista;
        }

        public int GuardarFacturacion(FacturacionCLS obj)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Facturacion (PacienteId, Monto, MetodoPago, FechaPago) VALUES (@PacienteId, @Monto, @MetodoPago, @FechaPago)", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@PacienteId", obj.PacienteId);
                        cmd.Parameters.AddWithValue("@Monto", obj.Monto);
                        cmd.Parameters.AddWithValue("@MetodoPago", obj.MetodoPago);
                        cmd.Parameters.AddWithValue("@FechaPago", obj.FechaPago);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }

        public int EliminarFacturacion(int idFacturacion)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Facturacion WHERE Id = @IdFacturacion", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@IdFacturacion", idFacturacion);

                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }

        public FacturacionCLS recuperarFacturacion(int idFacturacion)
        {
            FacturacionCLS obj = null;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, Monto, MetodoPago, FechaPago FROM Facturacion WHERE Id = @IdFacturacion", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@IdFacturacion", idFacturacion);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                obj = new FacturacionCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    Monto = dr.GetDecimal(2),
                                    MetodoPago = dr.GetString(3),
                                    FechaPago = dr.GetDateTime(4)
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en recuperarFacturacion: {ex.Message}");
                }
            }
            return obj;
        }






        public int GuardarCambioFacturacion(FacturacionCLS obj)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("UPDATE Facturacion SET PacienteId = @PacienteId, Monto = @Monto, MetodoPago = @MetodoPago, FechaPago = @FechaPago WHERE Id = @Id", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Id", obj.Id);
                        cmd.Parameters.AddWithValue("@PacienteId", obj.PacienteId);
                        cmd.Parameters.AddWithValue("@Monto", obj.Monto);
                        cmd.Parameters.AddWithValue("@MetodoPago", obj.MetodoPago);
                        cmd.Parameters.AddWithValue("@FechaPago", obj.FechaPago);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }
    }
}
