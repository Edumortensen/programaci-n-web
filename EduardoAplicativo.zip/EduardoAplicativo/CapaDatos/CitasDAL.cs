﻿using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class CitasDAL : CadenaDAL
    {

        public List<CitasCLS> listarCitas()
        {
            List<CitasCLS> lista = new List<CitasCLS>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, MedicoId, FechaHora, Estado FROM Citas", cn))
                    {
                        cmd.CommandType = CommandType.Text;

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                lista.Add(new CitasCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    MedicoId = dr.GetInt32(2),
                                    FechaHora = dr.GetDateTime(3),
                                    Estado = dr.IsDBNull(4) ? null : dr.GetString(4)
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en listarCitas: {ex.Message}");
                    lista = new List<CitasCLS>(); // Devolver lista vacía en vez de null
                }
            }
            return lista;
        }

        public List<CitasCLS> filtrarCitas(CitasCLS obj)
        {
            List<CitasCLS> lista = new List<CitasCLS>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, MedicoId, FechaHora, Estado FROM Citas WHERE (@PacienteId IS NULL OR PacienteId = @PacienteId) AND (@MedicoId IS NULL OR MedicoId = @MedicoId) AND (@Estado IS NULL OR Estado = @Estado)", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@PacienteId", (object)obj.PacienteId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@MedicoId", (object)obj.MedicoId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@Estado", (object)obj.Estado ?? DBNull.Value);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                lista.Add(new CitasCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    MedicoId = dr.GetInt32(2),
                                    FechaHora = dr.GetDateTime(3),
                                    Estado = dr.IsDBNull(4) ? null : dr.GetString(4)
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en filtrarCitas: {ex.Message}");
                    lista = new List<CitasCLS>(); // Devolver lista vacía en vez de null
                }
            }
            return lista;
        }

        public int GuardarCita(CitasCLS obj)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Citas (PacienteId, MedicoId, FechaHora, Estado) VALUES (@PacienteId, @MedicoId, @FechaHora, @Estado)", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@PacienteId", obj.PacienteId);
                        cmd.Parameters.AddWithValue("@MedicoId", obj.MedicoId);
                        cmd.Parameters.AddWithValue("@FechaHora", obj.FechaHora);
                        cmd.Parameters.AddWithValue("@Estado", obj.Estado);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }

        public int EliminarCita(int idCita)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Citas WHERE Id = @IdCita", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@IdCita", idCita);

                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }

        public CitasCLS recuperarCita(int idCita)
        {
            CitasCLS obj = null;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Id, PacienteId, MedicoId, FechaHora, Estado FROM Citas WHERE Id = @IdCita", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@IdCita", idCita);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                obj = new CitasCLS
                                {
                                    Id = dr.GetInt32(0),
                                    PacienteId = dr.GetInt32(1),
                                    MedicoId = dr.GetInt32(2),
                                    FechaHora = dr.GetDateTime(3),
                                    Estado = dr.IsDBNull(4) ? null : dr.GetString(4)
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error en recuperarCita: {ex.Message}");
                }
            }
            return obj;
        }

        public int GuardarCambioCita(CitasCLS obj)
        {
            int rpta = 0;
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                try
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("UPDATE Citas SET PacienteId = @PacienteId, MedicoId = @MedicoId, FechaHora = @FechaHora, Estado = @Estado WHERE Id = @Id", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Id", obj.Id);
                        cmd.Parameters.AddWithValue("@PacienteId", obj.PacienteId);
                        cmd.Parameters.AddWithValue("@MedicoId", obj.MedicoId);
                        cmd.Parameters.AddWithValue("@FechaHora", obj.FechaHora);
                        cmd.Parameters.AddWithValue("@Estado", obj.Estado);
                        rpta = cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    rpta = 0;
                    throw;
                }
            }
            return rpta;
        }
    }
}
